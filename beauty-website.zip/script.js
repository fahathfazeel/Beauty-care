let cart = JSON.parse(localStorage.getItem('cart')) || [];
function addToCart(product, price){
    cart.push({product, price});
    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${product} added to cart!`);
    updateCart();
}
function updateCart(){
    const cartItems = document.getElementById('cart-items');
    const totalPrice = document.getElementById('total-price');
    if(!cartItems) return;
    cartItems.innerHTML = '';
    let total = 0;
    cart.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.product} - $${item.price}`;
        cartItems.appendChild(li);
        total += item.price;
    });
    totalPrice.textContent = `Total: $${total}`;
}
function placeOrder(){
    if(cart.length === 0){
        alert("Your cart is empty!");
        return;
    }
    let message = "Hello, I want to order:\n";
    cart.forEach(item => { message += `- ${item.product} - $${item.price}\n`; });
    message += `Total: $${cart.reduce((sum, i)=>sum+i.price,0)}`;
    const whatsappLink = `https://wa.me/XXXXXXXXXXX?text=${encodeURIComponent(message)}`;
    window.open(whatsappLink, "_blank");
}
function submitForm(event){
    event.preventDefault();
    alert("Thank you! Your message has been sent.");
}
window.onload = updateCart;